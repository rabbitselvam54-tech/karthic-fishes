/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Fish, 
  Waves, 
  MapPin, 
  Phone, 
  Clock, 
  ChevronRight, 
  Menu, 
  X, 
  Droplets, 
  ShieldCheck, 
  Sparkles,
  Instagram,
  Facebook
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Collections', href: '#collections' },
    { name: 'Services', href: '#services' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-emerald-600 p-2 rounded-lg">
              <Fish className="text-white w-6 h-6" />
            </div>
            <span className={`text-xl font-bold tracking-tight ${scrolled ? 'text-slate-900' : 'text-white'}`}>
              Karthik <span className="text-emerald-500">Aquatic</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-emerald-500 ${scrolled ? 'text-slate-600' : 'text-white/90'}`}
              >
                {link.name}
              </a>
            ))}
            <a 
              href="tel:9845074803"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-full text-sm font-semibold transition-all shadow-lg shadow-emerald-600/20"
            >
              Call Now
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className={`${scrolled ? 'text-slate-900' : 'text-white'}`}
            >
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-slate-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="block px-3 py-4 text-base font-medium text-slate-700 hover:bg-slate-50 rounded-lg"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-4">
                <a 
                  href="tel:9845074803"
                  className="block w-full text-center bg-emerald-600 text-white py-3 rounded-lg font-bold"
                >
                  Call 9845074803
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?q=80&w=2024&auto=format&fit=crop" 
          alt="Beautiful Aquarium" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 via-slate-900/40 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-500/20 backdrop-blur-sm border border-emerald-500/30 px-3 py-1 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-100 text-xs font-bold uppercase tracking-wider">Premium Aquatic Experience</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
            Bring the <span className="text-emerald-400">Ocean</span> to Your Home
          </h1>
          <p className="text-lg text-slate-200 mb-8 leading-relaxed max-w-lg">
            Karthik Aquatic specializes in exotic tropical fish, custom-designed aquariums, and professional maintenance services to create your perfect underwater sanctuary.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 group shadow-xl shadow-emerald-900/20">
              Explore Collections
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all">
              Our Services
            </button>
          </div>
        </motion.div>
      </div>

      {/* Floating Stats */}
      <div className="absolute bottom-10 left-0 right-0 z-10 hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-3 gap-8 max-w-3xl">
            {[
              { label: 'Exotic Species', value: '200+' },
              { label: 'Happy Clients', value: '1.5k+' },
              { label: 'Years Experience', value: '10+' },
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl"
              >
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-slate-400 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Features = ({ onServiceClick }: { onServiceClick: (service: string) => void }) => {
  const features = [
    {
      icon: <Fish className="w-8 h-8 text-emerald-500" />,
      title: "Exotic Fish",
      desc: "Wide variety of healthy, vibrant tropical and marine fish sourced responsibly."
    },
    {
      icon: <Droplets className="w-8 h-8 text-emerald-500" />,
      title: "Custom Tanks",
      desc: "Bespoke aquarium designs tailored to fit your space and aesthetic perfectly."
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-emerald-500" />,
      title: "Expert Care",
      desc: "Professional maintenance and health consultations for your aquatic life."
    }
  ];

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-emerald-600 font-bold tracking-widest uppercase text-sm mb-3">Why Choose Us</h2>
          <p className="text-4xl font-bold text-slate-900 mb-6">Expertise in Every Drop</p>
          <p className="text-slate-600">We don't just sell fish; we provide a complete ecosystem support system to ensure your aquatic pets thrive in their new home.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {features.map((f, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="p-8 rounded-3xl bg-slate-50 border border-slate-100 transition-all hover:shadow-xl hover:shadow-slate-200/50 flex flex-col"
            >
              <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm mb-6">
                {f.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{f.title}</h3>
              <p className="text-slate-600 leading-relaxed mb-6 flex-grow">{f.desc}</p>
              <button 
                onClick={() => onServiceClick(f.title)}
                className="text-emerald-600 font-bold flex items-center gap-2 hover:gap-3 transition-all text-sm"
              >
                Inquire Now <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CollectionModal = ({ 
  isOpen, 
  onClose, 
  item 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  item: { name: string, category: string, img: string, desc: string } | null 
}) => {
  if (!item) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/90 backdrop-blur-md"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col md:flex-row"
          >
            <button 
              onClick={onClose}
              className="absolute top-6 right-6 z-10 bg-white/20 hover:bg-white/40 backdrop-blur-md text-white p-2 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="md:w-3/5 h-[300px] md:h-auto relative overflow-hidden">
              <img 
                src={item.img} 
                alt={item.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent md:hidden"></div>
            </div>

            <div className="md:w-2/5 p-8 md:p-12 flex flex-col justify-center">
              <span className="text-emerald-600 font-bold tracking-widest uppercase text-xs mb-3">{item.category}</span>
              <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">{item.name}</h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                {item.desc}
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3 text-slate-700">
                  <ShieldCheck className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm font-medium">Quarantined & Health Checked</span>
                </div>
                <div className="flex items-center gap-3 text-slate-700">
                  <Sparkles className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm font-medium">Vibrant Colors & Active Temperament</span>
                </div>
              </div>

              <button 
                onClick={() => {
                  onClose();
                  window.location.href = '#contact';
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
              >
                Inquire Availability
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const Collections = ({ onItemClick }: { onItemClick: (item: any) => void }) => {
  const items = [
    { 
      name: 'Discus Fish', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1200&auto=format&fit=crop',
      desc: 'Known as the "King of the Aquarium", Discus are prized for their majestic shape and incredible color patterns. They require specialized care but are truly rewarding.'
    },
    { 
      name: 'Nano Aquascapes', 
      category: 'Custom Design', 
      img: 'https://images.unsplash.com/photo-1501472312651-726afe119ff1?q=80&w=1200&auto=format&fit=crop',
      desc: 'Perfect for small spaces, our nano aquascapes are living pieces of art. We use premium stones, driftwood, and live plants to create miniature ecosystems.'
    },
    { 
      name: 'Marine Corals', 
      category: 'Saltwater', 
      img: 'https://images.unsplash.com/photo-1546024023-f0ff871233e4?q=80&w=1200&auto=format&fit=crop',
      desc: 'Bring the vibrant colors of the reef to your home. We offer a wide range of soft and hard corals, all sustainably sourced and fully acclimated.'
    },
    { 
      name: 'Goldfish Varieties', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1524704654690-b56c05c78a00?q=80&w=1200&auto=format&fit=crop',
      desc: 'From Orandas to Ranchus, our fancy goldfish are selected for their unique features and robust health. A classic choice for any indoor aquarium.'
    },
    { 
      name: 'Betta Splendens', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?q=80&w=1200&auto=format&fit=crop',
      desc: 'Our Bettas are hand-picked for their extraordinary finnage and intense coloration. Each one is a unique individual with its own personality.'
    },
    { 
      name: 'Clownfish', 
      category: 'Saltwater', 
      img: 'https://images.unsplash.com/photo-1544551763-8dd44758c2dd?q=80&w=1200&auto=format&fit=crop',
      desc: 'The most iconic marine fish, our Clownfish are captive-bred and very hardy. They form beautiful symbiotic relationships with anemones.'
    },
    { 
      name: 'Angelfish', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1535591273668-578e31182c4f?q=80&w=1200&auto=format&fit=crop',
      desc: 'Elegant and graceful, Freshwater Angelfish are a centerpiece for any larger community tank. We offer various strains including Marble and Koi.'
    },
    { 
      name: 'Neon Tetras', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1571752726703-5e7d1f6a986d?q=80&w=1200&auto=format&fit=crop',
      desc: 'These schooling fish create a stunning "neon" effect in the aquarium. Best kept in groups of 10 or more for their natural behavior.'
    },
    { 
      name: 'Arowana', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1501472312651-726afe119ff1?q=80&w=1200&auto=format&fit=crop',
      desc: 'The "Dragon Fish" is a symbol of luck and prosperity. These powerful surface-dwelling predators are for serious hobbyists with large tanks.'
    },
    { 
      name: 'Blue Tang', 
      category: 'Marine', 
      img: 'https://images.unsplash.com/photo-1520038410233-7141be7e6f97?q=80&w=1200&auto=format&fit=crop',
      desc: 'Famous for its vibrant blue body and yellow tail, the Blue Tang is a striking addition to any large marine aquarium.'
    },
    { 
      name: 'Flowerhorn', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1200&auto=format&fit=crop',
      desc: 'Known for their prominent nuchal hump and interactive nature, Flowerhorns are highly intelligent fish that often recognize their owners.'
    },
    { 
      name: 'Guppies', 
      category: 'Freshwater', 
      img: 'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?q=80&w=1200&auto=format&fit=crop',
      desc: 'Colorful, active, and easy to care for. Our fancy guppies come in a dazzling array of tail shapes and color combinations.'
    },
  ];

  return (
    <section id="collections" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-emerald-600 font-bold tracking-widest uppercase text-sm mb-3">Our Collections</h2>
            <p className="text-4xl font-bold text-slate-900">Featured Aquatic Life</p>
          </div>
          <button className="text-emerald-600 font-bold flex items-center gap-2 hover:gap-3 transition-all">
            View All Collections <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              onClick={() => onItemClick(item)}
              className="group relative overflow-hidden rounded-3xl bg-white shadow-sm cursor-pointer"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={item.img} 
                  alt={item.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                <span className="text-emerald-400 text-xs font-bold uppercase mb-1">{item.category}</span>
                <h3 className="text-white font-bold text-lg">{item.name}</h3>
                <div className="mt-2 flex items-center gap-2 text-white/80 text-xs font-medium">
                  <span>View Details</span>
                  <ChevronRight className="w-3 h-3" />
                </div>
              </div>
              <div className="p-4 md:hidden">
                <span className="text-emerald-600 text-xs font-bold uppercase">{item.category}</span>
                <h3 className="text-slate-900 font-bold">{item.name}</h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 md:p-16">
            <h2 className="text-emerald-500 font-bold tracking-widest uppercase text-sm mb-4">Get In Touch</h2>
            <p className="text-4xl font-bold text-white mb-8">Visit Our Showroom</p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="bg-emerald-500/20 p-3 rounded-xl">
                  <Phone className="text-emerald-500 w-6 h-6" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-1">Call Us</p>
                  <a href="tel:9845074803" className="text-white text-xl font-bold hover:text-emerald-400 transition-colors">
                    +91 98450 74803
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-emerald-500/20 p-3 rounded-xl">
                  <MapPin className="text-emerald-500 w-6 h-6" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-1">Location</p>
                  <p className="text-white text-lg font-medium leading-relaxed">
                    Karthik Aquatic,<br />
                    Bangalore, Karnataka, India
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-emerald-500/20 p-3 rounded-xl">
                  <Clock className="text-emerald-500 w-6 h-6" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-1">Business Hours</p>
                  <p className="text-white text-lg font-medium">
                    Mon - Sat: 10:00 AM - 9:00 PM<br />
                    Sun: 11:00 AM - 7:00 PM
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12 flex gap-4">
              <a href="#" className="w-12 h-12 bg-white/5 hover:bg-emerald-500 transition-all rounded-full flex items-center justify-center text-white">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-12 h-12 bg-white/5 hover:bg-emerald-500 transition-all rounded-full flex items-center justify-center text-white">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="lg:w-1/2 relative min-h-[400px]">
            <img 
              src="https://images.unsplash.com/photo-1520038410233-7141be7e6f97?q=80&w=1000&auto=format&fit=crop" 
              alt="Shop Interior" 
              className="absolute inset-0 w-full h-full object-cover grayscale opacity-50"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-emerald-600/20 mix-blend-overlay"></div>
            <div className="absolute inset-0 flex items-center justify-center p-8">
              <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-sm w-full">
                <h3 className="text-2xl font-bold text-slate-900 mb-4 text-center">Send a Message</h3>
                <form className="space-y-4">
                  <input type="text" placeholder="Your Name" className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all" />
                  <input type="tel" placeholder="Phone Number" className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all" />
                  <textarea placeholder="How can we help?" rows={3} className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"></textarea>
                  <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-emerald-600/20 transition-all">
                    Send Inquiry
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-50 pt-16 pb-8 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-emerald-600 p-1.5 rounded-lg">
                <Fish className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900">
                Karthik <span className="text-emerald-500">Aquatic</span>
              </span>
            </div>
            <p className="text-slate-500 max-w-sm leading-relaxed">
              Your trusted partner for all things aquatic. From exotic fish to custom tank setups, we bring the beauty of the underwater world to your doorstep.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-slate-900 mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-slate-500 hover:text-emerald-600 transition-colors">Home</a></li>
              <li><a href="#collections" className="text-slate-500 hover:text-emerald-600 transition-colors">Collections</a></li>
              <li><a href="#services" className="text-slate-500 hover:text-emerald-600 transition-colors">Services</a></li>
              <li><a href="#contact" className="text-slate-500 hover:text-emerald-600 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Services</h4>
            <ul className="space-y-4">
              <li className="text-slate-500">Custom Tank Design</li>
              <li className="text-slate-500">Fish Health Consultation</li>
              <li className="text-slate-500">Weekly Maintenance</li>
              <li className="text-slate-500">Aquascaping</li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            © {new Date().getFullYear()} Karthik Aquatic. All rights reserved.
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-slate-400 hover:text-slate-600 text-sm">Privacy Policy</a>
            <a href="#" className="text-slate-400 hover:text-slate-600 text-sm">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

const ServiceModal = ({ 
  isOpen, 
  onClose, 
  serviceName 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  serviceName: string 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd send this to a backend
    console.log('Service Inquiry:', { service: serviceName, ...formData });
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 3000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-white rounded-[2rem] shadow-2xl w-full max-w-lg overflow-hidden"
          >
            <div className="p-8 md:p-10">
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              {submitted ? (
                <div className="text-center py-12">
                  <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Sparkles className="text-emerald-600 w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Inquiry Sent!</h3>
                  <p className="text-slate-600">Thank you for your interest in our {serviceName} service. We'll contact you shortly.</p>
                </div>
              ) : (
                <>
                  <div className="mb-8">
                    <h3 className="text-2xl font-bold text-slate-900 mb-2">Service Inquiry</h3>
                    <p className="text-slate-600">Interested in <span className="text-emerald-600 font-semibold">{serviceName}</span>? Fill out the form below.</p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                      <input 
                        required
                        type="text" 
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="Enter your name" 
                        className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1">Phone Number</label>
                      <input 
                        required
                        type="tel" 
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        placeholder="Enter your phone number" 
                        className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address (Optional)</label>
                      <input 
                        type="email" 
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="Enter your email" 
                        className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1">Basic Information / Requirements</label>
                      <textarea 
                        rows={3} 
                        value={formData.message}
                        onChange={(e) => setFormData({...formData, message: e.target.value})}
                        placeholder="Tell us more about what you need..." 
                        className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
                      ></textarea>
                    </div>
                    <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-emerald-600/20 transition-all mt-4">
                      Submit Inquiry
                    </button>
                  </form>
                </>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default function App() {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  return (
    <div className="min-h-screen bg-white font-sans selection:bg-emerald-100 selection:text-emerald-900">
      <Navbar />
      <Hero />
      <Features onServiceClick={(service) => setSelectedService(service)} />
      <Collections onItemClick={(item) => setSelectedItem(item)} />
      <Contact />
      <Footer />
      
      <ServiceModal 
        isOpen={!!selectedService} 
        onClose={() => setSelectedService(null)} 
        serviceName={selectedService || ''} 
      />

      <CollectionModal 
        isOpen={!!selectedItem} 
        onClose={() => setSelectedItem(null)} 
        item={selectedItem} 
      />
    </div>
  );
}
